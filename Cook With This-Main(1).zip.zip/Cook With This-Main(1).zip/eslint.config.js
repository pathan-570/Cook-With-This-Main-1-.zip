import js from "@eslint/js";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";

export default [
  // Ignore build/dist files
  {
    ignores: ["dist", "node_modules"],
  },

  // Base config for JS + JSX
  {
    files: ["**/*.{js,jsx}"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.es2021,
      },
    },
    plugins: {
      reactHooks,
      reactRefresh,
    },
    rules: {
      // Extend recommended sets
      ...js.configs.recommended.rules,
      ...reactHooks.configs.recommended.rules,

      // Custom rules
      "no-unused-vars": [
        "warn",
        {
          varsIgnorePattern: "^[A-Z_]", // allow constants like API_URL
          argsIgnorePattern: "^_", // ignore unused args starting with _
        },
      ],
      "react-refresh/only-export-components": [
        "warn",
        { allowConstantExport: true },
      ],
    },
  },
];